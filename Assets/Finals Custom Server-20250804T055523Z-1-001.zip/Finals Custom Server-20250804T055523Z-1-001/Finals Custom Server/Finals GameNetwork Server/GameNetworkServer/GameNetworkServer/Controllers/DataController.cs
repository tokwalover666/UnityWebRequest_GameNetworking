﻿using Microsoft.AspNetCore.Mvc;
using GameNetworkServer.Models;
using Newtonsoft.Json;

namespace GameNetworkServer.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DataController : ControllerBase
{
    private readonly string _filePath = Path.Combine(Directory.GetCurrentDirectory(), "Data", "data.json");

    [HttpPost]
    public IActionResult SaveData([FromBody] PlayerData item)
    {
        if (item == null)
            return BadRequest("Invalid item data.");

        // Serialize the object to JSON
        string json = JsonConvert.SerializeObject(item, Formatting.Indented);

        // Save to file
        System.IO.File.WriteAllText(_filePath, json);

        return Ok(new { message = "Data saved successfully.", item });
    }

    [HttpGet]
    public IActionResult GetData()
    {
        if (!System.IO.File.Exists(_filePath))
            return NotFound("Data file not found.");

        string json = System.IO.File.ReadAllText(_filePath);
        var data = JsonConvert.DeserializeObject<PlayerData>(json);

        return Ok(data);
    }
}