﻿using System.Numerics;
using Newtonsoft.Json;

namespace GameNetworkServer.Models;

public class PlayerData
{
    [JsonProperty("playerName")]
    public string PlayerName  { get; set; }
    
    [JsonProperty("playerHealth")]  
    public int PlayerHealth { get; set; }
    
    [JsonProperty("score")]
    public int Score { get; set; }
    
    [JsonProperty("playerPosition")]
    public Vector3 PlayerPosition { get; set; }
}